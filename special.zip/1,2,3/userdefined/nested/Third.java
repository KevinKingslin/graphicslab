package userdefined.nested;

public class Third {
    public void printthird(){
        System.out.println("This is third class");
    }
}
