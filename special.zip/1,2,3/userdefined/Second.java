package userdefined;

public class Second {
    public void printsecond(){
        System.out.println("This is second class");
    }
}
