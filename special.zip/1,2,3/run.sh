javac *.java
appletviewer special.html