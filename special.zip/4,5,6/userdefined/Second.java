package userdefined;

public class Second {
    public String printsecond(){
        System.out.println("This is second class");
        return "This is second class";
    }
}
