// Question 4

import userdefined.Second;

public class First extends Second {
    public int variable;

    public void print() {
    }

    public static void main(String[] args) {
        new First().printsecond();

    }
}
