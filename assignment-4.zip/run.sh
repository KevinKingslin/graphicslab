javac *.java
javac packages/*.java
java shapes
